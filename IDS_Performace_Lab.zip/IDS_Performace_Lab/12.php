                                    <?php
                                            error_reporting(E_ALL);
                                            ini_set('display_errors', 1);
                                            require('db.php');

                                            // Define the getAlgorithmInfo function
                                            function getAlgorithmInfo($selectedAlgorithm) {
                                                global $con;
                                                
                                                $query = "SELECT * FROM algorithm WHERE AlgorithmName = ?";
                                                $stmt = $con->prepare($query);
                                                
                                                if ($stmt) {
                                                    $stmt->bind_param("s", $selectedAlgorithm);
                                                    $stmt->execute();
                                                    
                                                    if ($stmt->error) {
                                                        echo "Error executing the query: " . $stmt->error;
                                                        return false;
                                                    }
                                                    
                                                    $result = $stmt->get_result();
                                                    $algorithmInfo = $result->fetch_assoc();
                                                    
                                                    if ($algorithmInfo) {
                                                        return $algorithmInfo;
                                                    } else {
                                                        return false;
                                                    }
                                                } else {
                                                    echo "Error preparing the statement: " . $con->error;
                                                    return false;
                                                }
                                            }



                                            // Define the getPapersByAlgorithm function
                                            function getPapersByAlgorithm($algorithmID) {
                                                global $con;
                                                global $selectedAlgorithm; // Make sure $selectedAlgorithm is defined and holds the correct algorithm name
                                                
                                                // Define the SQL query
                                                $query = "
                                                SELECT
                                                    p.PaperID,
                                                    p.Title AS PaperTitle,
                                                    p.PublishYear,
                                                    p.Link,
                                                    COALESCE(d.DatasetName, 'N/A') AS DatasetName,
                                                    COALESCE(a.AccuracyPercentage, 'N/A') AS AccuracyPercentage,
                                                    at.AttackType
                                                FROM
                                                    paper p
                                                INNER JOIN
                                                    paper_algorithm pa ON p.PaperID = pa.PaperID
                                                INNER JOIN
                                                    algorithm al ON pa.AlgorithmID = al.AlgorithmID
                                                LEFT JOIN
                                                    dataset_paper dp ON p.PaperID = dp.PaperID
                                                LEFT JOIN
                                                    dataset d ON dp.DatasetID = d.DatasetID
                                                LEFT JOIN
                                                    accuracy a ON dp.DatasetID = a.DatasetID
                                                LEFT JOIN
                                                    attack_paper ap ON p.PaperID = ap.PaperID
                                                LEFT JOIN
                                                    attack at ON ap.AttackID = at.AttackID
                                                WHERE
                                                    al.AlgorithmName = ?";
                                                
                                                // Prepare and execute the query
                                                $stmt = $con->prepare($query);
                                                
                                                if ($stmt) {
                                                    $stmt->bind_param("s", $selectedAlgorithm);
                                                    $stmt->execute();
                                                    
                                                    if ($stmt->error) {
                                                        echo "Error executing the query: " . $stmt->error;
                                                        return [];
                                                    }
                                                    
                                                    $result = $stmt->get_result();
                                                    $papers = [];
                                                    
                                                    while ($row = $result->fetch_assoc()) {
                                                        $papers[] = $row;
                                                    }
                                                    
                                                    return $papers;
                                                } else {
                                                    echo "Error preparing the statement: " . $con->error;
                                                    return [];
                                                }
                                            }


                                            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                                                $selectedIdsType = $_POST["selectedIdsType"];
                                                $selectedAlgorithm = $_POST["selectedAlgorithm"];
                                                
                                                // Retrieve data based on user selections
                                                if ($selectedIdsType === "machineLearning") {
                                                    $algorithmType = "Machine Learning";
                                                } elseif ($selectedIdsType === "deepLearning") {
                                                    $algorithmType = "Deep Learning";
                                                } elseif ($selectedIdsType === "hybridlearning") {
                                                    $algorithmType = "Hybrid";
                                                }
                                                
                                                // Get information about the selected algorithm
                                                $algorithmInfo = getAlgorithmInfo($selectedAlgorithm);
                                                
                                                if ($algorithmInfo) {
                                                    $algorithmID = $algorithmInfo["AlgorithmID"];
                                                    $algorithmName = $algorithmInfo["AlgorithmName"];

                                                    echo "Selected IDS Type: $algorithmType<br>";
                                                    echo "Selected Algorithm: $algorithmName<br>";
                                                    
                                                    // Get papers related to the selected algorithm
                                                    $papers = getPapersByAlgorithm($algorithmID);
                                                
                                                    foreach ($papers as $paper) { ?>
                                                        <div class="col-lg-4 col-md-6">
                                                            <div class="single-plan text-center">
                                                                <div class="introd-area">
                                                                    <div class="content">
                                                                        <p class="mdr">Accuracy</p>
                                                                        <h4>
                                                                            <span class="number"><?php echo $paper["AccuracyPercentage"]; ?></span>
                                                                            <span class="right">
                                                                                <span>%</span>
                                                                            </span>
                                                                        </h4>
                                                                    </div>
                                                                </div>
                                                                <div class="head-area">
                                                                    <h5><?php echo $algorithmName; ?></h5>
                                                                </div>
                                                                <div class="plan-list">
                                                                    <div class="single">
                                                                        <h6>Dataset</h6>
                                                                        <p><?php echo $paper["DatasetName"]; ?></p>
                                                                    </div>
                                                                    <div class="single">
                                                                        <h6>Attacks</h6>
                                                                        <p><?php echo $paper["AttackType"]; ?></p>
                                                                    </div>
                                                                    <div class="single">
                                                                        <h6><?php echo $paper["PaperTitle"]; ?></h6>
                                                                        <p>Paper</p>
                                                                    </div>
                                                                    <div class="single">
                                                                        <h6>Publish Year</h6>
                                                                        <p><?php echo $paper["PublishYear"];   ?></p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

       

                                                   <?php

                                                    }

                                                } 

                                                else {
                                                    echo "Selected Algorithm not found.";
                                                }
                                            }


                                            ?>