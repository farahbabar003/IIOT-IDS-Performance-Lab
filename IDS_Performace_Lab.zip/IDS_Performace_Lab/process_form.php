<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require('db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
}
require('db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = $_POST['fname'];
    $lastName = $_POST['lname'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Sanitize the inputs before using them in a query
    $firstName = mysqli_real_escape_string($con, $firstName);
    $lastName = mysqli_real_escape_string($con, $lastName);
    $email = mysqli_real_escape_string($con, $email);
    $password = mysqli_real_escape_string($con, $password);

    $query = "INSERT INTO users (first_name, last_name, email, password) 
              VALUES ('$firstName', '$lastName', '$email', '$password')";
    
    $result = mysqli_query($con, $query);

    if ($result) {
        header("Location: login.html");
        exit(); 
    } else {
        echo "Error: " . mysqli_error($con);
    }
}
?>

