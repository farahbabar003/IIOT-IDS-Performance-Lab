<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>IIOT IDS Performance Lab</title>

    <link rel="shortcut icon" href="assets/images/fav.png" type="image/x-icon">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawesome.min.css">
    <link rel="stylesheet" href="assets/css/jquery-ui.css">
    <link rel="stylesheet" href="assets/css/plugin/nice-select.css">
    <link rel="stylesheet" href="assets/css/plugin/slick.css">
    <link rel="stylesheet" href="assets/css/arafat-font.css">
    <link rel="stylesheet" href="assets/css/plugin/animate.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
    <!-- start preloader -->
    <div class="preloader" id="preloader"></div>
    <!-- end preloader -->

    <!-- Scroll To Top Start-->
    <a href="javascript:void(0)" class="scrollToTop"><i class="fas fa-angle-double-up"></i></a>
    <!-- Scroll To Top End -->

    <!-- header-section start -->
    <header class="header-section">
        <div class="overlay">
            <div class="container">
                <div class="row d-flex header-area">
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <a class="navbar-brand" href="index.html">
                            <img src="assets/images/logo.png" class="logo" alt="logo">
                        </a>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- header-section end -->

    <!-- Apply for a loan In start -->
     <section class="grow-confidence">
        <div class="overlay pt-120">
            <div class="container wow fadeInUp">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="section-header text-center">

                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-10">
                        <div class="form-content">
                            <div class="section-header text-center">
                                
                                    <?php
                                            error_reporting(E_ALL);
                                            ini_set('display_errors', 1);
                                            require('db.php');

                                            // Define the getAlgorithmInfo function
                                            function getAlgorithmInfo($selectedAlgorithm) {
                                                global $con;
                                                
                                                $query = "SELECT * FROM algorithm WHERE AlgorithmName = ?";
                                                $stmt = $con->prepare($query);
                                                
                                                if ($stmt) {
                                                    $stmt->bind_param("s", $selectedAlgorithm);
                                                    $stmt->execute();
                                                    
                                                    if ($stmt->error) {
                                                        echo "Error executing the query: " . $stmt->error;
                                                        return false;
                                                    }
                                                    
                                                    $result = $stmt->get_result();
                                                    $algorithmInfo = $result->fetch_assoc();
                                                    
                                                    if ($algorithmInfo) {
                                                        return $algorithmInfo;
                                                    } else {
                                                        return false;
                                                    }
                                                } else {
                                                    echo "Error preparing the statement: " . $con->error;
                                                    return false;
                                                }
                                            }



                                            // Define the getPapersByAlgorithm function
                                            function getPapersByAlgorithm($algorithmID) 
                                            {
                                                global $con;
                                                global $selectedAlgorithm; // Make sure $selectedAlgorithm is defined and holds the correct algorithm name
                                                
                                                // Define the SQL query
                                                $query = "SELECT 
    p.PaperID, 
    p.Title AS PaperTitle, 
    p.PublishYear, 
    p.Link, 
    COALESCE(d.DatasetName, 'N/A') AS DatasetName, 
    COALESCE(max_a.MaxAccuracyPercentage, 'N/A') AS AccuracyPercentage, 
    COALESCE(GROUP_CONCAT(DISTINCT at.AttackType ORDER BY at.AttackType ASC), 'N/A') AS AttackType
FROM 
    (
        SELECT DISTINCT pa.PaperID
        FROM 
            paper_algorithm pa 
        INNER JOIN 
            algorithm al ON pa.AlgorithmID = al.AlgorithmID 
        WHERE 
            al.AlgorithmName = ?
    ) AS filtered_papers
INNER JOIN 
    paper p ON filtered_papers.PaperID = p.PaperID
LEFT JOIN 
    dataset_paper dp ON p.PaperID = dp.PaperID 
LEFT JOIN 
    dataset d ON dp.DatasetID = d.DatasetID 
LEFT JOIN (
    SELECT 
        dp.PaperID, 
        MAX(a.AccuracyPercentage) AS MaxAccuracyPercentage
    FROM 
        dataset_paper dp 
    LEFT JOIN 
        accuracy a ON dp.DatasetID = a.DatasetID 
    GROUP BY 
        dp.PaperID
) max_a ON p.PaperID = max_a.PaperID
LEFT JOIN 
    attack_paper ap ON p.PaperID = ap.PaperID 
LEFT JOIN 
    attack at ON ap.AttackID = at.AttackID
GROUP BY
    p.PaperID, p.Title, p.PublishYear, p.Link, DatasetName, max_a.MaxAccuracyPercentage";
                                                $stmt = $con->prepare($query);                                            
                                                if ($stmt) 
                                                {
                                                    $stmt->bind_param("s", $selectedAlgorithm);
                                                    $stmt->execute();
                                                    
                                                    if ($stmt->error) {
                                                        echo "Error executing the query: " . $stmt->error;
                                                        return [];
                                                    }
                                                    
                                                    $result = $stmt->get_result();
                                                    $papers = [];
                                                    
                                                    while ($row = $result->fetch_assoc()) {
                                                        $papers[] = $row;
                                                    }
                                                    
                                                    return $papers;
                                                } else {
                                                    echo "Error preparing the statement: " . $con->error;
                                                    return [];
                                                }
                                            }

                                            if ($_SERVER["REQUEST_METHOD"] == "POST") 
                                            {
                                                $selectedIdsType = $_POST["selectedIdsType"];
                                                $selectedAlgorithm = $_POST["selectedAlgorithm"];

                                                if ($selectedIdsType === "machineLearning") 
                                                {
                                                    $algorithmType = "Machine Learning";
                                                } 
                                                elseif ($selectedIdsType === "deepLearning") 
                                                {
                                                    $algorithmType = "Deep Learning";
                                                } 
                                                elseif ($selectedIdsType === "hybridlearning") 
                                                {
                                                    $algorithmType = "Hybrid";
                                                }
                                                $algorithmInfo = getAlgorithmInfo($selectedAlgorithm);
                                                ?>
                                                <h5 class="title"><?php echo $algorithmType; ?> IDS for your IIOT</h5>
                                                <?php
                                                if ($algorithmInfo) 
                                                {
                                                    $algorithmID = $algorithmInfo["AlgorithmID"];
                                                    $algorithmName = $algorithmInfo["AlgorithmName"];

                                                    // Get papers related to the selected algorithm
                                                    $papers = getPapersByAlgorithm($algorithmID);
                                                
                                                    foreach ($papers as $paper) 
                                                        { ?>

                                                        <div class="col-lg-12">
                                                            <div class="single-plan text-center">
                                                                <div class="introd-area">
                                                                    <div class="content">
                                                                        <p class="mdr">Accuracy</p>
                                                                        <h4>
                                                                            <span class="number"><?php echo $paper["AccuracyPercentage"]; ?></span>
                                                                            <span class="right">
                                                                                <span>%</span>
                                                                            </span>
                                                                        </h4>
                                                                    </div>
                                                                </div>
                                                                <div class="head-area">
                                                                    <h5><?php echo $algorithmName; ?></h5>
                                                                </div>
                                                                <div class="plan-list">
                                                                    <div class="single">
                                                                        <h6>Dataset</h6>
                                                                        <p><?php echo $paper["DatasetName"]; ?></p>
                                                                    </div>
                                                                    <div class="single">
                                                                        <h6>Attacks</h6>
                                                                        <p><?php echo $paper["AttackType"]; ?></p>
                                                                    </div>
                                                                    <div class="single">
                                                                        <h6><?php echo $paper["PaperTitle"]; ?></h6>
                                                                        <p>Paper</p>
                                                                    </div>
                                                                    <div class="single">
                                                                        <h6>Publish Year</h6>
                                                                        <p><?php echo $paper["PublishYear"]; ?></p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                   <?php
                                                    }
                                                } 
                                                else {
                                                    echo "Selected Algorithm not found.";
                                                }
                                            }


                                            ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Apply for a loan In end -->

    <!-- Footer Area Start -->
    <div class="footer-section">
        <div class="container pt-120">
            <div class="row">
                <div class="col-12">
                    <div class="footer-bottom">
                        <div class="left">
                            <p> Copyright © <a href="index.html">IDS IIOT Performance Lab</a> | Designed by
                                <a href="https://themeforest.net/user/pixelaxis">Farah Babar</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="img-area">
            <img src="assets/images/footer-Illu-left.png" class="left" alt="Images">
            <img src="assets/images/footer-Illu-right.png" class="right" alt="Images">
        </div>
    </div>
    <!-- Footer Area End -->

    <!--==================================================================-->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/jquery-ui.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/fontawesome.js"></script>
    <script src="assets/js/plugin/slick.js"></script>
    <script src="assets/js/plugin/jquery.nice-select.min.js"></script>
    <script src="assets/js/plugin/wow.min.js"></script>
    <script src="assets/js/plugin/plugin.js"></script>
    <script src="assets/js/main.js"></script>
</body>

</html>
