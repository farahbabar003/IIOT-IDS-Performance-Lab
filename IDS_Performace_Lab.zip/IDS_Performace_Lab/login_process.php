<?php
// Include your database connection file (db.php or any other)
error_reporting(E_ALL);
ini_set('display_errors', 1);
require('db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = $_POST['email'];
    $password = $_POST['password'];

    // Sanitize the inputs before using them in a query

    $email = mysqli_real_escape_string($con, $email);
    $password = mysqli_real_escape_string($con, $password);


    $query = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
    $result = mysqli_query($con, $query);
    
    if ($result && mysqli_num_rows($result) > 0) {
        // Set a session to indicate the user is logged in
        $_SESSION['user_logged_in'] = true;

        // Redirect to the IDS_Search page
        header("Location: IDS_Search.html");
        exit();
    } else 

    {
        // Invalid credentials
        $_SESSION['login_error'] = "Invalid credentials. Please try again.";
        //header("Location: login.html");
        //exit();
    }
}
?>

