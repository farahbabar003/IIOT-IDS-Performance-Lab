<?php

    $con = new mysqli("localhost", "admin", "Admin2242", "ids_iiot");
    // Check connection
    if (mysqli_connect_errno()){
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
?>
